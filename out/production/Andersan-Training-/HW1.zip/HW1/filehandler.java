import java.io.*;
import java.util.*;

public class FileHandler {

    public static void saveReservations(List<Reservation> reservations, String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Reservation res : reservations) {
                // Format: meetingRoom|date|time
                writer.write(res.getMeetingRoom() + "|" + res.getDate() + "|" + res.getTime());
                writer.newLine();
            }
        }
    }

    public static List<Reservation> loadReservations(String filename) throws IOException {
        List<Reservation> reservations = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) {
            return reservations; // Return empty list if file not found
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 3) {
                    String meetingRoom = parts[0];
                    String date = parts[1];
                    String time = parts[2];
                    Reservation res = new Reservation(meetingRoom, date, time);
                    reservations.add(res);
                }
            }
        }
        return reservations;
    }
}
