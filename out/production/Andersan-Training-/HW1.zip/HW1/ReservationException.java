package HW1;

public class ReservationException {
    public ReservationException(String message) {
        super(message);
    }
}
